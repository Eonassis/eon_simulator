*************************
Graphical degree sequence
*************************

.. automodule:: networkx.algorithms.graphical
.. autosummary::
   :toctree: generated/

   is_graphical
   is_digraphical
   is_multigraphical
   is_pseudographical
   is_valid_degree_sequence_havel_hakimi
   is_valid_degree_sequence_erdos_gallai


