SparseGraph6 
============

Graph6
------
.. automodule:: networkx.readwrite.graph6
.. autosummary::
   :toctree: generated/

   parse_graph6
   read_graph6
   generate_graph6
   write_graph6

Sparse6
-------
.. automodule:: networkx.readwrite.sparse6
.. autosummary::
   :toctree: generated/

   parse_sparse6
   read_sparse6
   generate_sparse6
   write_sparse6

